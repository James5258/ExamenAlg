﻿// variables

int ganados = 3;
int contador_usuario = 0;
int contador_computadora = 0;
string empate = "";

//Codigo

Console.WriteLine("Bienvendio a piedra papel o tijera, el que gane 3 juegos es el vencedor");

// loop hasta que cualquiera de los dos gane 3 juegos
while (contador_computadora < ganados && contador_usuario < ganados)
{
    
    Random random = new Random();
    int random_number = random.Next(1, 4);

    // code
    Console.WriteLine("Puntaje: Usuario " + contador_usuario + " Computadora " + contador_computadora);
    Console.WriteLine("Escoge:");
    Console.WriteLine("1: Piedra");
    Console.WriteLine("2: Papel");
    Console.WriteLine("3: Tijera");


    // Cambio de variable a la selección de cualquier opción numerica para mostrar su igual en palabras
    int PPT;


    //Comprobar que la entrada sea válida
    while (!int.TryParse(Console.ReadLine(), out PPT) || (PPT < 1 || PPT > 3))
    {
        Console.WriteLine("Por favor, ingresa una entrada válida");
    }
    // if para dar el valor correspondiente en caso de empate
    if (PPT == random_number)
    {
        Console.Clear();
        switch (PPT)
        {
            case 1:
                empate = "Piedra";
                break;
            case 2:
                empate = "Papel";
                break;
            case 3:
                empate = "Tijera";
                break;
        }
        Console.WriteLine("Ambos escogieron " + empate);
        Console.WriteLine("Hubo un empate");


    }
    else if (PPT == 1 && random_number == 3)
    {
        Console.Clear();
        Console.WriteLine("Piedra v Tijera");
        contador_usuario++;
        Console.WriteLine("Ganaste, llevas " + contador_usuario + " Ganados");
    }
    else if (PPT == 2 && random_number == 1)
    {
        Console.Clear();
        Console.WriteLine("Papel v Piedra");
        contador_usuario++;
        Console.WriteLine("Ganaste, llevas " + contador_usuario + " Ganados");
    }
    else if (PPT == 3 && random_number == 2)

    {
        Console.Clear();
        Console.WriteLine("Tijera v Papel");
        contador_usuario++;
        Console.WriteLine("Ganaste, llevas " + contador_usuario + " Ganados");
    }
    else if (PPT == 3 && random_number == 1)
    {
        Console.Clear();
        Console.WriteLine("Tijera v Piedra");
        contador_computadora++;
        Console.WriteLine("Perdiste, llevas " + contador_computadora + " perdidos");
    }
    else if (PPT == 2 && random_number == 3)
    {
        Console.Clear();
        Console.WriteLine("Papel v Tijera");
        contador_computadora++;
        Console.WriteLine("Perdiste, llevas " + contador_computadora + " perdidos");
    }
    else if (PPT == 1 && random_number == 2)
    {
        Console.Clear();
        Console.WriteLine("Piedra v Papel");
        contador_computadora++;
        Console.WriteLine("Perdiste, llevas " + contador_computadora + " perdidos");
    }
    else { Console.Clear();
    }
}

//Mensaje de ganado o perdido
if (contador_usuario == 3)
{
    Console.Clear();
    Console.WriteLine("¡Has ganado 3 juegos! Felicidades.");
    Console.WriteLine("Puntaje: Usuario " + contador_usuario + " Computadora " + contador_computadora);


}
else if (contador_computadora == 3)
{
    Console.Clear();
    Console.WriteLine("La computadora ha ganado 3 juegos. Mejor suerte la próxima vez.");
    Console.WriteLine("Puntaje: Usuario " + contador_usuario + " Computadora " + contador_computadora);

}